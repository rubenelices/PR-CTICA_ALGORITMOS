def calcular_media_aritmetica(num1, num2, num3):
    media = (num1 + num2 + num3) / 3
    return media

num1 = int(input("Ingrese el primer numero: "))
num2 = int(input("Ingrese el segundo numero: "))
num3 = int(input("Ingrese el tercer numero: "))
media_aritmetica = calcular_media_aritmetica(num1, num2, num3)
print("La media aritmética es:", media_aritmetica)
