def calcular_media_ponderada(num1, num2, num3, coef1, coef2, coef3):
    suma_ponderada = (num1 * coef1) + (num2 * coef2) + (num3 * coef3)
    suma_coeficientes = coef1 + coef2 + coef3
    media_ponderada = suma_ponderada / suma_coeficientes
    return media_ponderada


num1 = int(input("Ingrese el primer numero: "))
num2 = int(input("Ingrese el segundo numero: "))
num3 = int(input("Ingrese el tercer numero: "))
coef1 = float(input("Ingrese el valor del coeficiente de ponderación para el primer número: "))
coef2 = float(input("Ingrese el valor del coeficiente de ponderación para el segundo número: "))
coef3 = float(input("Ingrese el valor del coeficiente de ponderación para el tercer número: "))
media_ponderada = calcular_media_ponderada(num1, num2, num3, coef1, coef2, coef3)
print("La media ponderada es:", media_ponderada)
