def calcular_precio_con_impuestos(precio_sin_impuestos, porcentaje_iva):
    impuestos = precio_sin_impuestos * (porcentaje_iva / 100)
    precio_con_impuestos = precio_sin_impuestos + impuestos
    return precio_con_impuestos


precio_sin_impuestos = int(input("Introduzca el precio sin impuestos: "))
porcentaje_iva = 21
precio_con_impuestos = calcular_precio_con_impuestos(precio_sin_impuestos, porcentaje_iva)
print("El precio con todos los impuestos incluidos es:", precio_con_impuestos)
