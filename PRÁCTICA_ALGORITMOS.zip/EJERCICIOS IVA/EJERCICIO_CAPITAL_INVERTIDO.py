def calcular_intereses(capital, tasa_interes, tiempo_meses):
    intereses = (capital * tasa_interes / 100) * tiempo_meses
    return intereses

capital = int(input("¿Cual es el capital invertido?: "))
tasa_interes = 5
tiempo_meses = int(input("¿Cuántos meses ha estado el capital invertido?: "))
intereses_generados = calcular_intereses(capital, tasa_interes, tiempo_meses)
print("Los intereses generados son:", intereses_generados)
