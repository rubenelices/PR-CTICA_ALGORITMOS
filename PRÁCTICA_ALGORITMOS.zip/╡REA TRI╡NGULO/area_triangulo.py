def calcular_area_triangulo(base, altura):
    area = (base * altura) / 2
    return area


base = float(input("Introduzca la medida de la base: "))
altura = float(input("Introduzca la altura: "))
area_triangulo = calcular_area_triangulo(base, altura)
print("El área del triángulo es:", area_triangulo)
