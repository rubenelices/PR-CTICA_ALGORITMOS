def calcular_horas_extra(salario_bruto_mensual, horas_extra_trabajadas):
    # Calcular la tarifa por hora normal
    tarifa_hora_normal = salario_bruto_mensual / (52 * 35 / 12)

    # Inicializar el importe total de las horas extra
    importe_horas_extra = 0

    # Calcular el importe de las horas extra
    if horas_extra_trabajadas <= 35:
        return importe_horas_extra  # No hay horas extra
    elif 36 <= horas_extra_trabajadas <= 43:
        # Horas extra entre la 36ª y la 43ª: tarifa aumentada en un 125%
        importe_horas_extra += (horas_extra_trabajadas - 35) * tarifa_hora_normal * 1.25
    else:
        # Horas extra a partir de la 44ª: tarifa aumentada en un 150%
        importe_horas_extra += (43 - 35) * tarifa_hora_normal * 1.25  # Horas entre la 36ª y la 43ª
        importe_horas_extra += (horas_extra_trabajadas - 43) * tarifa_hora_normal * 1.5  # Horas a partir de la 44ª

    return round(importe_horas_extra, 2)

salario_bruto_mensual = float(input("Introduzca el salario: "))
horas_extra_trabajadas = int(input("introduzca las horas trabajadas en el mes, incluyendo las extras: "))  

importe_horas_extra = calcular_horas_extra(salario_bruto_mensual, horas_extra_trabajadas)
print("El importe de las horas extra a pagar es:", importe_horas_extra, "euros")
