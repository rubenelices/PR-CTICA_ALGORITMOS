class Cuenta:
    def __init__(self, saldo_inicial, descubierto_autorizado=0):
        self.saldo = saldo_inicial
        self.descubierto_autorizado = descubierto_autorizado

    def depositar(self, cantidad):
        self.saldo += cantidad

    def retirar(self, cantidad):
        if self.saldo - cantidad >= -self.descubierto_autorizado:
            self.saldo -= cantidad
            print("Retiro exitoso. Nuevo saldo:", self.saldo)
        else:
            print("No se puede realizar el retiro. Saldo insuficiente.")

    def consultar_saldo(self):
        return self.saldo

cuenta = float(input("Introduzca el saldo de la cuenta: "))
descubierto = float(input("Introduzca la cantidad del descubierto: "))

cuenta_con_descubierto = Cuenta(saldo_inicial=cuenta, descubierto_autorizado=descubierto)

cantidad_retiro = int(input("Introduzca la cantidad que desea retirar: "))

cuenta_con_descubierto.retirar(cantidad_retiro)  

# Ejemplo de uso con descubierto autorizado de 200 euros
#cuenta --- 2000€
#descubierto --- 200€
#cantidad de retiro --- 2100€
